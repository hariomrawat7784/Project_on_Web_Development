<?php

include('dbcon.php');

if (isset($_POST['submit'])) {
    $image = $_FILES['image'];

    $imagename = $image['name'];
    $imagepath = $image['tmp_name'];
    $imageeror = $image['error'];

    $name =  mysqli_real_escape_string($con, $_POST['name']);
    $gender =   mysqli_real_escape_string($con, $_POST['gender']);
    $number =  mysqli_real_escape_string($con, $_POST['number']);
    $email =   mysqli_real_escape_string($con, $_POST['email']);
    $pass =   mysqli_real_escape_string($con, $_POST['pass']);
    $cpass =   mysqli_real_escape_string($con, $_POST['cpass']);

    // echo $name, $gender, $number, $email, $pass, $cpass;
    $chack = $pass == $cpass;


    $spass = password_hash($pass, PASSWORD_BCRYPT);
    $scpass = password_hash($cpass, PASSWORD_BCRYPT);

    $token = bin2hex(random_bytes(5));

    $chack_email = "SELECT * from user where email ='$email'";
    $query = mysqli_query($con, $chack_email);
    $email_count = mysqli_num_rows($query);

    // echo $email_count;
    if ($email_count > 0) {
        $email_a = "email already exsist <br>";
    } else {

        if ($chack) {

            if($imageeror == 0){
                $destfile = 'upload/'. $imagename;
                $i_upload = move_uploaded_file($imagepath, $destfile);
            }

            $sql =   "INSERT INTO `user` (`image`, `name`, `gender`, `number`, `email`, `pass`,  `cpass` , `token`, `status`) VALUES ('$destfile', '$name', '$gender', '$number', '$email','$spass', '$scpass', '$token','inactive');";

            $d_query = mysqli_query($con, $sql);


            if ($d_query) {


                require_once 'PHPMailer/PHPMailerAutoload.php';

                $mail = new PHPMailer;

                //$mail->SMTPDebug = 3;                               // Enable verbose debug output

                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
                $mail->Password = 'AbhiRj@2672';                           // SMTP password
                $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 465;                                    // TCP port to connect to

                $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
                $mail->addAddress($email);     // Add a recipient
                // $mail->addAddress('ellen@example.com');               // Name is optional
                // $mail->addReplyTo('info@example.com', 'Information');
                // $mail->addCC('cc@example.com');
                // $mail->addBCC('bcc@example.com');

                // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
                $mail->isHTML(true);                                  // Set email format to HTML

                $mail->Subject = 'Skillshares : skillshare activation code';
                $mail->Body    = "Hello, $name. click hare to activate your account https://www.skillshares.in/php/a_account.php?token=$token";
                // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                if (!$mail->send()) {
                    $email_m = 'Message could not be sent.';
                    $$email_e =  'Mailer Error: ' . $mail->ErrorInfo;
                } else {
                    $email_s = 'Congratulation ! You have successfull register<br> chack your gmail and activate your account.';
                }
            } else {
                $email_d = "user data is Not inserted";
            }
        } else {
            $email_p =  "password are not matching";
        }
    }
}

?>
