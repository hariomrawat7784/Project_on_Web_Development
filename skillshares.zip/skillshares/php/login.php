
<?php

session_start();

include('dbcon.php');

if(isset($_POST['submit'])) {
  $email = $_POST['email'];
  $pass = $_POST['pass'];

  $email_search = "SELECT * from user where email ='$email' and status='active'";
  $query = mysqli_query($con,$email_search);
  $email_count = mysqli_num_rows($query);
 
  $e_search = "SELECT * from user where email ='$email'";
  $e_query = mysqli_query($con,$e_search);
  $e_count = mysqli_num_rows($e_query);

  if(!$e_count) {
    $e_mass = " Email not found sign up first .";
  }else{

  if($email_count){
    $email_pass = mysqli_fetch_assoc($query); 
    $dbpass = $email_pass['pass'];
    $_SESSION['user_name'] = $email_pass['name'];
    $pass_decode = password_verify($pass,$dbpass);

    if($pass_decode){
      $mass = "not replace location";
      header('location:my_account.php');
    }
    else{
      $i_pass = "Password Incorrect";
    }
    }else{
      $i_email =  "Kindly, First check your email to activate your account";

  }
  }
}
?>
