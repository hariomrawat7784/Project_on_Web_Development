<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:../login.php');
};
include('dbcon.php');

$email = $_GET['email'];

$query_0 = "SELECT * from  user where email ='$email'";
$u_query =  mysqli_query($con, $query_0);
$u_count = mysqli_num_rows($u_query);

if ($u_count) {
    $user_data_user = mysqli_fetch_array($u_query);
    $image = $user_data_user['image'];


    $query = "SELECT * from  meeting_abhi where email ='$email'";
    $e_query =  mysqli_query($con, $query);
    $e_count = mysqli_num_rows($e_query);


    if ($e_count) {

        $user_data = mysqli_fetch_array($e_query);
        $a_email = $user_data['email'];
        $meeting = $user_data['meeting'];
        $amount = $user_data['amount'];
        $register_date = $user_data['register_date'];


    $query_hari = "SELECT * from  meeting_hari where email ='$email'";
    $e_query_hari =  mysqli_query($con, $query_hari);
    $e_count_hari = mysqli_num_rows($e_query_hari);

    if($e_count_hari){

          $user_data_hari = mysqli_fetch_array($e_query_hari);
        // $a_email = $user_data_hari['email'];
        $meeting_hari = $user_data_hari['meeting'];
        $amount_hari = $user_data_hari['amount'];
        $register_date_hari = $user_data_hari['register_date'];

            $query_st = "SELECT * from  meeting_st where email ='$email'";
                $e_query_st =  mysqli_query($con, $query_st);
                $e_count_st = mysqli_num_rows($e_query_st);
        if($e_count_st){
                    $user_data_st = mysqli_fetch_array($e_query_st);
                    // $a_email = $user_data_hari['email'];
                    $meeting_st = $user_data_hari['meeting'];
                    $amount_st = $user_data_hari['amount'];
                    $register_date_st = $user_data_st['register_date'];
        }else{
                $st_user = "Data not found";
        }
    }else {
            $h_user = "Data not found";
    }

    } else {
        $d_user = "Data not fount";
    }
} else {
    $d_user_n = "data not goted";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <link rel="stylesheet" href="../css/style_01.css">
    <link rel="stylesheet" href="../css/Respons.css">
    <link rel="stylesheet" href="../css/my_account.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tapestry&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <script src="https://kit.fontawesome.com/6018fcc079.js" crossorigin="anonymous"></script>

    <title>Skillshares : "My account"</title>
    <link href="/image/icon.png" rel="icon">
    <link href="/image/icon.png" rel="apple-touch-icon">
    <style>
        .ac_sub #btn {
            position: absolute;
            top: 100px;
            left: 90%;
            border: none;
            background: none;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.5);
            font-size: 18px;
            font-family: 'Acme', sans-serif;
            padding: 5px;
        }

        .ac_sub #btn a {
            color: #fff;
            text-decoration: none;
        }

        .image h2 {
            font-size: 22px;
            color: #fff;
            margin: 20px;
        }

        .image img {
            border: 2px solid #fff;
            border-radius: 50%;
            margin-bottom: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.5);
        }

        table {
            color: #fff;
            font-family: 'Acme', sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }

        @media only screen and (max-width: 480px) {
            .ac_sub #btn {
                position: absolute;
                top: 80px;
                left: 70%;
            }
        }
    </style>
</head>

<body>
    <div class="lc">
        <a href="https://api.whatsapp.com/message/U3S4TRIYFME3D1?autoload=1&app_absent=0"><img src="../image/lc.png" alt="live chat"></a>
    </div>
    <div class="nav">
        <div class="logo">
            <a href="https://www.skillshares.in/"><span>S </span>kill<span> S </span>hares</a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="https://www.skillshares.in/"><span>H</span>ome</a></li>
                <li><a href="https://www.skillshares.in/#about"><span>A</span>bout</a></li>
                <li><a href="https://www.skillshares.in/#skill"><span>S</span>kills</a></li>
                <li><a href="https://www.skillshares.in/#prof"><span>P</span>rofessionals</a></li>
                <li><a href="https://www.skillshares.in/#cont">contact us</a></li>
            </ul>
            <div class="social_m">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>
    <div class="ac_main">
        <div class="ac_sub">
            <button id="btn"><a href="logout.php">Logout</a></button>
            <div class="image">
                <img src="<?php echo '../' . $image; ?>" alt="" height="100" width="100">
                <h2>
                    <?php
                    echo $_SESSION['user_name'];
                    ?>
                </h2>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Meeting</th>
                        <th>amount</th>
                        <th>Resister_date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $meeting; ?></td>
                        <td><?php echo $amount; ?></td>
                        <td><?php echo $register_date; ?></td>
                    </tr>
                     <tr>
                        <td><?php echo $meeting_hari; ?></td>
                        <td><?php echo $amount_hari; ?></td>
                        <td><?php echo $register_date_hari; ?></td>
                    </tr>
                     <tr>
                        <td><?php echo $meeting_st; ?></td>
                        <td><?php echo $amount_st; ?></td>
                        <td><?php echo $register_date_st; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script src="../js/script.js"></script>
</body>

</html>