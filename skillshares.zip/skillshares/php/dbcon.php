<?php

$server = "sql109.unaux.com";
$username = "unaux_31640495";
$password = "Skillshare@123";
$db = "unaux_31640495_skillshare";

$con = mysqli_connect($server,$username,$password,$db);

if($con){
   $s_conn = "Connection successful.";

}else{
    $f_conn = "Connection is not successful.";
}

?>
   