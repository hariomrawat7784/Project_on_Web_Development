<?php

$server = "localhost";
$username = "root";
$password = "";

$con = mysqli_connect($server, $username, $password);
mysqli_select_db($con, "skillshare");
if ($con) {

    $name = $_POST["name"];
    $gender = $_POST["gender"];
    $number = $_POST["number"];
    $email = $_POST["email"];
    $amount = $_POST["amount"];

    // echo $name, $gender, $email, $amount;

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $qemail = "SELECT * from meetweb where email = '$email'";
        $result = mysqli_query($con, $qemail);
        $num = mysqli_num_rows($result);
        include('razorpay.php');
    }
        // if ($num >= 1) {
        //     echo " 'already resister' ";
        // } else {
          
        //     include('razorpay.php');

        //     $q_insert = "INSERT INTO `meetweb`(`name`, `gender`, `number`, `email`, `amount`) VALUES ('$name', '$gender', '$number', '$email', '$amount');";
        //     $insert = mysqli_query($con, $q_insert);

        //     if ($insert) {
        //         $insert_01 =  " successfully inserted";

        //         require 'PHPMailer/PHPMailerAutoload.php';

        //         $mail = new PHPMailer;

        //         //$mail->SMTPDebug = 3;                               // Enable verbose debug output

        //         $mail->isSMTP();                                      // Set mailer to use SMTP
        //         $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        //         $mail->SMTPAuth = true;                               // Enable SMTP authentication
        //         $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
        //         $mail->Password = 'AbhiRj@2672';                           // SMTP password
        //         $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        //         $mail->Port = 465;                                    // TCP port to connect to

        //         $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
        //         $mail->addAddress($email);     // Add a recipient
        //         // $mail->addAddress('ellen@example.com');               // Name is optional
        //         // $mail->addReplyTo('info@example.com', 'Information');
        //         // $mail->addCC('cc@example.com');
        //         // $mail->addBCC('bcc@example.com');

        //         // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        //         // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        //         $mail->isHTML(true);                                  // Set email format to HTML

        //         $mail->Subject = 'Skillshares : registration';
        //         $mail->Body    = '<h3>You are register succesfully </h3>';
        //         // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        //         if (!$mail->send()) {
        //             echo 'Message could not be sent.';
        //             echo 'Mailer Error: ' . $mail->ErrorInfo;
        //         } else {
        //             echo 'Message has been sent';
        //         }
          // } 
        else {
                echo " try again " . mysqli_connect_error();
            }
        }
     else {
        echo "invalid email";
    }
