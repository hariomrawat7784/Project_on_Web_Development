<?php
$insert = false;
if (isset($_POST['c_submit'])) {
    include 'dbcon.php';

    if (!$con) {
        die("connection to this database failed due to" . mysqli_connect_error());
    }
    // echo "Success connecting to the db";

    $name = $_POST["name"];
    $number = $_POST["number"];
    $email = $_POST["email"];
    $massage = $_POST["massage"];

    $sql = "INSERT INTO `contact` (`name`, `number`, `email`, `massage`) VALUES ('$name', '$number', '$email', '$massage');";
    //echo $sql;
    $c_insert = mysqli_query($con, $sql);

    if ($c_insert) {
        //echo "Successfully insreted";
        $insert = true;

        require 'PHPMailer/PHPMailerAutoload.php';

        $mail = new PHPMailer;

        //$mail->SMTPDebug = 3;                               // Enable verbose debug output

        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
        $mail->Password = 'AbhiRj@2672';                           // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 465;                                    // TCP port to connect to

        $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
        $mail->addAddress('abhishekchauhan322243@gmail.com');     // Add a recipient
        // $mail->addAddress('ellen@example.com');               // Name is optional
        // $mail->addReplyTo('info@example.com', 'Information');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = 'Skillshares : Congratulation massage';
        $mail->Body    = "<p>
        <p>Hello !'$name' </p> 

        <p>Thanks for your suggestion and query ('$massage') we will contact with you.</p>
  
        <p>Official social media platforms 👇</p>

        <p>Facebook_ https://bit.ly/3OGV2WH</p>

        <p>Instagram_ https://bit.ly/3KGxv4O</p>

        <p>Telegram_ https://t.me/successtalkswithsatyam</p>
        
        </p>";
        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if (!$mail->send()) {
            $mag_n = 'Message could not be sent.';
            $mag_e = 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            $mag_s = "Thanks! $name for your suggestion and query we will contact with you.";
            
        }
    } else {
        $error = "ERROR : $sql <br> $con->error";
    }

    $con->close();
}
?>
