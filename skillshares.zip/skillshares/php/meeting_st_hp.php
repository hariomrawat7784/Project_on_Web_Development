<?php

$server = "localhost";
$username = "root";
$password = "";

$con = mysqli_connect($server, $username, $password);
mysqli_select_db($con, "skillshare");
if ($con) {

    $name = $_POST["name"];
    $gender = $_POST["gender"];
    $number = $_POST["number"];
    $email = $_POST["email"];
    $amount = $_POST["amount"];

    // echo $name, $gender, $email, $amount;

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $qemail = "SELECT * from meetweb where email = '$email'";
        $result = mysqli_query($con, $qemail);
        $num = mysqli_num_rows($result);

        if ($num >= 1) {
            $exit =  " 'already resister' ";
        } else {

            $q_insert = "INSERT INTO `meetweb`(`name`, `gender`, `number`, `email`, `amount`) VALUES ('$name', '$gender', '$number', '$email', '$amount');";
            $insert = mysqli_query($con, $q_insert);

            if ($insert) {

                require 'PHPMailer/PHPMailerAutoload.php';

                $mail = new PHPMailer;

                //$mail->SMTPDebug = 3;                               // Enable verbose debug output

                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
                $mail->Password = 'AbhiRj@2672';                           // SMTP password
                $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 465;                                    // TCP port to connect to

                $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
                $mail->addAddress($email);     // Add a recipient
                // $mail->addAddress('ellen@example.com');               // Name is optional
                // $mail->addReplyTo('info@example.com', 'Information');
                // $mail->addCC('cc@example.com');
                // $mail->addBCC('bcc@example.com');

                // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
                $mail->isHTML(true);                                  // Set email format to HTML

                $mail->Subject = 'Skillshares : Congratulation massage';
                $mail->Body    = '<p style="font-size:22px";>
                Hello Sir/Mam <br>

                Thanks for completing the registration for upcoming webinar on Basic Human Psychology held by Team Satyam Vishwakrma.<br>
                
                Here is the meeting link👇<br>
                
                Topic : Basic human psychology to grow in your personal & professional life.<br>
                
                Time: May 6, 2022 07:00 PM (PAN India)<br>
                
                Join Zoom Meeting<br>
                https://us04web.zoom.us/j/73286772887?pwd=do62oNSLcwyLmwPYhu61i42lCaqxQC.1<br>
                
                Meeting ID: 732 8677 2887<br>
                Passcode: TSV2022<br>
                
                Note_📍<br>
                
                * Only 50 free slots are allotted.<br>
                * Kindly join the webinar before 2 min or at sharp 07:00pm.<br>
                
                Regards & Invitation from_💌<br>
                Team Satyam Vishwakarma 🏅<br>
                
                You can connect with us on various social media platforms 👇<br>
                
                Facebook_ https://bit.ly/3OGV2WH<br>
                
                Instagram_ https://bit.ly/3KGxv4O<br>
                
                Telegram_ https://t.me/successtalkswithsatyam<br>
                
                </p>';
                // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                if (!$mail->send()) {
                    $n_sent = 'Message could not be sent.';
                    $n_sent_0 = 'Mailer Error: ' . $mail->ErrorInfo;
                } else {
                    $sent = 'Congratulation<br> You have successfull register';
                }
            } else {
                echo " try again " . mysqli_connect_error();
            }
        }
    } else {
        echo "invalid email";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Congratulation</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .main {
            height: 100vh;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .sub_main {
            height: 50%;
            width: 50%;
            border-radius: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.5);
            display: grid;
            place-items: center;
        }

        .sub_main a {
            text-decoration: none;
            font-size: 18px;
            font-weight: bolder;
            font-family: 'Acme', sans-serif;
            color: #eee;
            border: 1px solid rgb(255, 255, 255);
            border-radius: 40%;
            margin: 2px;
            padding: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>

<body>
    <div class="main">
        <div class="sub_main">
            <h3>
                <?php
                if ($num >= 1) {
                    echo  $exit;
                } else {
                    if (!$mail->send()) {
                        echo $n_sent, $n_sent_0;
                    } else {
                        echo $sent;
                    }
                }
                ?>
            </h3>
            <a href="https://www.skillshares.in/">Home</a>
        </div>
    </div>
</body>

</html>