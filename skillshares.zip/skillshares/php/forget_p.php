<?php

include('dbcon.php');

if(isset($_POST['submit'])){

    if(isset($_GET['token'])) {
    $token = $_GET['token'];

    $pass =   mysqli_real_escape_string($con, $_POST['pass']);
    $cpass =   mysqli_real_escape_string($con, $_POST['cpass']);
    
    $chack = $pass == $cpass;
    
    
    $newpass = password_hash($pass, PASSWORD_BCRYPT);
    $newcpass = password_hash($cpass, PASSWORD_BCRYPT);
    
    
    if($chack){
            $updatequery  = " UPDATE user  SET pass = '$newpass' where token = '$token'"; 
            $iquery = mysqli_query($con,$updatequery);

            
                    if($iquery){

                        $p_update =  "your password is updated ! please login with new passord.";
                        // header('location:../login.html');
                        
                    
                    }else{
                        $p_n_update =  "your password is not updated ! please try agin.";
                        // header('location:reset');
                    }

                         
                }else{
                    $pass_n =  "password are not matching";
                }
            }else{
                $t_n_fount = "no token found";
                echo $t_n_fount;
            }

                    
}   

?>
