<?php

include('dbcon.php');

if (isset($_POST['submit'])) {

    $email =   mysqli_real_escape_string($con, $_POST['email']);

    $email_query = " SELECT * from user where email ='$email'";
    $query = mysqli_query($con, $email_query);
    $email_count = mysqli_num_rows($query);

    if ($email_count) {

        $user_data = mysqli_fetch_array($query);

        $name = $user_data['name'];
        $token = $user_data['token'];

        require_once 'PHPMailer/PHPMailerAutoload.php';

        $mail = new PHPMailer;

        //$mail->SMTPDebug = 3;                               // Enable verbose debug output

        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
        $mail->Password = 'AbhiRj@2672';                           // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 465;                                    // TCP port to connect to

        $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
        $mail->addAddress($email);     // Add a recipient
        // $mail->addAddress('ellen@example.com');               // Name is optional
        // $mail->addReplyTo('info@example.com', 'Information');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = 'Skillshares : skillshare reset password';
        $mail->Body    = "Hello, $name. click hare to reset your password https://www.skillshares.in/recover_pass.php?token=$token";
        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if (!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            $c_email =  'please check your email to set password';
        } 

    } else {
        $i_email = "No email found";
    }
}

?>