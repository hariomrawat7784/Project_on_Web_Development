<?php

$server = "sql109.unaux.com";
$username = "unaux_31640495";
$password = "Skillshare@123";

$con = mysqli_connect($server, $username, $password);
mysqli_select_db($con, "unaux_31640495_skillshare");
if ($con) {
     echo "con success";

    $sql = "SELECT name, email, massage FROM contact";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<br>Name: " . $row["name"] . " email :" . $row["email"] . "<br>";

           require_once 'PHPMailer/PHPMailerAutoload.php';

            $mail = new PHPMailer;

            //$mail->SMTPDebug = 3;                               // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
            $mail->Password = 'AbhiRj@2672';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;                                    // TCP port to connect to

            $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
            $mail->addAddress($row["email"]);     // Add a recipient
            // $mail->addAddress('ellen@example.com');               // Name is optional
            // $mail->addReplyTo('info@example.com', 'Information');
            // $mail->addCC('cc@example.com');
            // $mail->addBCC('bcc@example.com');

            // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = 'Skillshares : massage';
            $mail->Body    = '<p>
                       
                 <p>Thank you for your suggestion </p>
                <p>You can connect with us on various social media platforms 👇</p>
                <p>Facebook_ https://bit.ly/3OGV2WH</p>
                Instagram_ https://bit.ly/3KGxv4O</p>
                <p>Telegram_ https://t.me/successtalkswithsatyam</p>
                </p>'.$row["massage"];
            // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            if (!$mail->send()) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
                echo 'Congratulation<br> You have successfull register';
            }
        }
        
    } else {
        echo "0 results";
    }
}
