
<?php
include 'dbcon.php';
session_start();
if ($con) {

    $email = $_POST["email"];
    $amount = $_POST["amount"];
    
        $qemail = "SELECT * from user where email = '$email'";
        $result = mysqli_query($con, $qemail);
        $num = mysqli_num_rows($result);

        if($num) {
             
            $m_email = "SELECT * from meeting_abhi where email = '$email'";
            $m_result = mysqli_query($con, $m_email);
            $m_num = mysqli_num_rows($m_result);

            if($m_num){
                $m_mass = "You are already registered in meeting";
            }else {
             
            $email_pass = mysqli_fetch_assoc($result);
             
            $name = $email_pass['name'];
            $gender = $email_pass['gender'];
            $number = $email_pass['number'];

            include 'razorpay-php/pay.php';

            $q_insert = "INSERT INTO `meeting_abhi` (`name`, `gender`, `number`, `email`, `amount`, `meeting`) VALUES ('$name', '$gender', '$number', '$email', '$amount', 'webdevelopment');";
            $insert = mysqli_query($con, $q_insert);
        
                    if ($insert) {
        
                        require 'PHPMailer/PHPMailerAutoload.php';
        
                        $mail = new PHPMailer;
        
                        //$mail->SMTPDebug = 3;                               // Enable verbose debug output
        
                        $mail->isSMTP();                                      // Set mailer to use SMTP
                        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                        $mail->SMTPAuth = true;                               // Enable SMTP authentication
                        $mail->Username = 'abhishekchauhan322243@gmail.com';                 // SMTP username
                        $mail->Password = 'AbhiRj@2672';                           // SMTP password
                        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                        $mail->Port = 465;                                    // TCP port to connect to
        
                        $mail->setFrom('abhishekchauhan322243@gmail.com', 'skillshares.in');
                        $mail->addAddress($email);     // Add a recipient
                        // $mail->addAddress('ellen@example.com');               // Name is optional
                        // $mail->addReplyTo('info@example.com', 'Information');
                        // $mail->addCC('cc@example.com');
                        // $mail->addBCC('bcc@example.com');
        
                        // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
                        $mail->isHTML(true);                                  // Set email format to HTML
        
                        $mail->Subject = 'Skillshares : Congratulation massage';
                        $mail->Body    = "<p>
                        <p>Hello, $name </p>
        
                        <p>Thanks for completing the registration for upcoming webinar on Canva held by Skillshares</p>
                        
                       
                        <p>You can connect with us on various social media platforms 👇</p>
                        
                        <p>Facebook_ https://bit.ly/3OGV2WH</p>
                        
                        <p>Instagram_ https://bit.ly/3KGxv4O</p>
                        
                        <p>Telegram_ https://t.me/successtalkswithsatyam</p>
                        
                        </p>";
                        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        
                        if (!$mail->send()) {
                            $n_sent = 'Message could not be sent.';
                            $n_sent_0 = 'Mailer Error: ' . $mail->ErrorInfo;
                        } else {
                            $sent = "Congratulation ! $name <br> You have successfull register chack your email we sent all information about your order";
                        }
                    } else {
                        echo " try again " . mysqli_connect_error();
                    }

                }
        }
        
        else {
            $sin =  "sin up first";
        }
}
?>
