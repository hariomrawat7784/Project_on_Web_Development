<?php
include('dbcon.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    echo "Token = ",$token;

    $updat_equery = "UPDATE user set status= 'active' where token = '$token'";

    $query = mysqli_query($con, $updat_equery);

    if ($query) {
        echo "token updated successfully";
        header('location:../login.php');
    } else {
        echo "status is inactive";
        header('location:../index.php');
    }
} else {
    echo " Token not goted";
}
