<?php include 'php/singup.php'; ?>
<?php include 'php/contact.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_01.css">
    <link rel="stylesheet" href="css/Respons.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tapestry&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <script src="https://kit.fontawesome.com/6018fcc079.js" crossorigin="anonymous"></script>

    <title>Skillshares : "Amazing skills improvement e-learning platform"</title>
    <link href="image/icon.png" rel="icon">
    <link href="image/icon.png" rel="apple-touch-icon">
</head>

<body>
    <div class="sing" id= "sign_up">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="but">
                <i class="fa-solid fa-xmark"></i>
            </div>
            <p>SIGN UP HERE</p>
            <p>
                <?php
                if(isset($_POST['submit'])){
                if ($email_count > 0) {
                    echo $email_a;
                } else {
                    if ($chack) {
                        if ($d_query) {
                            if (!$mail->send()) {
                                echo $email_m, $$email_e;
                            } else {
                                echo $email_s;
                            }
                        } else {
                            echo "try again";
                        }
                    } else {
                        echo $email_p;
                    }
                }
            }
                ?>
            </p>
            <input type="text" name="name" placeholder="Enter your name" required>
            <label for="image" id="gen">Choose your image</label><br>
            <input type="file" name="image" placeholder="Choose your image" required>
            <p id="gen"><span id="m_h">S</span>elect your gender</p>
            <input type="radio" name="gender" value="Male" class="radio" required>
            <label for="Male">Male</label><br>
            <input type="radio" name="gender" value="Female" class="radio" required>
            <label for="Female">Female</label><br>
            <input type="radio" name="gender" value="Transgender" class="radio" required>
            <label for="Transgender">Transgender</label><br>
            <input type="number" name="number" placeholder="Enter your number" required>
            <input type="email" name="email" placeholder="Enter your mail" required>
            <input type="password" name="pass" placeholder="Enter your password" required>
            <input type="password" name="cpass" placeholder="Confirm your password" required>
            <input type="submit" value="Sign up" name="submit">
            <p>Have a account <a href="login.php"> Click here ?</a></p>
        </form>
    </div>
    <div class="lc">
        <a href="https://api.whatsapp.com/message/U3S4TRIYFME3D1?autoload=1&app_absent=0"><img src="image/lc_01.png" alt="live chat"></a>
    </div>
    <div class="nav">
        <div class="logo">
            <a href="https://skillshares.in"><span>S </span>kill<span> S </span>hares</a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="#"><span>H</span>ome</a></li>
                <li><a href="#about"><span>A</span>bout</a></li>
                <li><a href="#skill"><span>S</span>kills</a></li>
                <li><a href="#prof"><span>P</span>rofessionals</a></li>
                <li><a href="#cont">Contact us</a></li>
                <li class="uniqe">Sign Up</li>
                <li class="uniqe log"><a href="login.php"><i class="fa-regular fa-user"></a></i></li>
            </ul>
            <div class="social_m">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>
    <div class="home">
        <div class="item">
            <div class="quotes">
                <h2>" The power of skills "</h2>
                <p>
                    “Skills are the most powerful weapon which can leads you towards success in your life.
                    If you also want to become a Attractive personality or develop/enhance yourself by learning new
                    skills like Personality development, Communication skills & web development canva designing seo many
                    more, than scroll down to register yourself in your favourite topic and start learning from
                    experts.".
                </p>
                <a href="#meeting"><span>M</span>eetings</a>
            </div>
            <div class="grap">
                <img src="image/bg_04.png" alt="">
            </div>
        </div>
        <div class="svg">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
                <path fill="#fff" fill-opacity="1" d="M0,160L48,170.7C96,181,192,203,288,213.3C384,224,480,224,576,197.3C672,171,768,117,864,117.3C960,117,1056,171,1152,165.3C1248,160,1344,96,1392,64L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
                </path>
            </svg>
        </div>
    </div>
    <div class="About" id="about">
        <svg id="svg_02" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 220">
            <path fill="#ffd700" fill-opacity="1" d="M0,96L40,101.3C80,107,160,117,240,101.3C320,85,400,43,480,42.7C560,43,640,85,720,96C800,107,880,85,960,90.7C1040,96,1120,128,1200,138.7C1280,149,1360,139,1400,133.3L1440,128L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z">
            </path>
        </svg>

        <div class="A_01">
            <h2><span>A</span>bout <span>U</span>s</h2>
        </div>
        <div class="About_data">
            <div class="A_02">
                <img src="image/bg_03.png" alt="bg_01">
            </div>
            <div class="A_03">

                <h3><span>T</span>he <span>S</span>killshares</h3>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sapiente tempore sed fuga id porro,
                    corporis
                    similique nihil sequi voluptatem commodi reprehenderit modi neque eos enim non a iste veniam
                    facilis?
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sapiente tempore sed fuga id porro,
                    corporis
                    similique nihil sequi voluptatem commodi reprehenderit modi neque eos enim non a iste veniam
                    facilis?
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sapiente tempore sed fuga id porro,
                    corporis
                    similique nihil sequi voluptatem commodi reprehenderit modi neque eos enim non a iste veniam
                    facilis?

                </p>

            </div>
        </div>
        <svg id="svg_01" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 220">
            <path fill="#ffd700" fill-opacity="1" d="M0,96L40,101.3C80,107,160,117,240,101.3C320,85,400,43,480,42.7C560,43,640,85,720,96C800,107,880,85,960,90.7C1040,96,1120,128,1200,138.7C1280,149,1360,139,1400,133.3L1440,128L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z">
            </path>
        </svg>
    </div>
    <div class="slider_box" id="meeting">
        <svg id="svg_02" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 110">
            <path fill="#ffd700" fill-opacity="1" d="M0,96L40,101.3C80,107,160,117,240,101.3C320,85,400,43,480,42.7C560,43,640,85,720,96C800,107,880,85,960,90.7C1040,96,1120,128,1200,138.7C1280,149,1360,139,1400,133.3L1440,128L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z">
            </path>
        </svg>
        <div class="s_heading">
            <h3><span>M</span> eeting</h3>
        </div>
        <div class="slider">
            <div class="wrapper">
                <div class="carousel owl-carousel ">
                    <div class="card card-1">
                        <a href="meeting_st.php"><img src="image/m_st_02.jpeg" alt=""></a>
                    </div>
                    <div class="card card-2">
                        <a href="meeting_abhi.php"><img src="image/Abhi_01.png" alt=""></a>
                    </div>
                    <div class="card card-3">
                        <a href="meeting_hari.php"><img src="image/hari_02.png" alt=""></a>
                    </div>
                    <div class="card card-4">
                        <a href="meeting_hari.php"><img src="image/Ah_01.png" alt=""></a>
                    </div>
                    <div class="card card-5">
                        <a href="meeting_abhi.php"><img src="image/Abhi_03.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
        <svg id="svg_m" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 240">
            <path fill="#ffd700" fill-opacity="1" d="M0,224L34.3,208C68.6,192,137,160,206,133.3C274.3,107,343,85,411,101.3C480,117,549,171,617,165.3C685.7,160,754,96,823,90.7C891.4,85,960,139,1029,154.7C1097.1,171,1166,149,1234,154.7C1302.9,160,1371,192,1406,208L1440,224L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z">
            </path>
        </svg>
    </div>

    <div class="skill" id="skill">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 240">
            <path fill="#ffd700" fill-opacity="1" d="M0,96L24,101.3C48,107,96,117,144,101.3C192,85,240,43,288,48C336,53,384,107,432,117.3C480,128,528,96,576,85.3C624,75,672,85,720,96C768,107,816,117,864,144C912,171,960,213,1008,202.7C1056,192,1104,128,1152,112C1200,96,1248,128,1296,138.7C1344,149,1392,139,1416,133.3L1440,128L1440,0L1416,0C1392,0,1344,0,1296,0C1248,0,1200,0,1152,0C1104,0,1056,0,1008,0C960,0,912,0,864,0C816,0,768,0,720,0C672,0,624,0,576,0C528,0,480,0,432,0C384,0,336,0,288,0C240,0,192,0,144,0C96,0,48,0,24,0L0,0Z">
            </path>
        </svg>
        <div class="h_skill">
            <h3><Span>S</Span>kills</h3>
        </div>
        <div class="m_skill">
            <a href="prof_st.php">
                <div class="card skill_c">
                    <h2><span>C</span>ommuniation</h2>
                </div>
            </a>
            <a href="prof_st.php">
                <div class="card skill_l">
                    <h2><span>L</span>eader<span>S</span>hip</h2>
                </div>
            </a>
            <a href="prof_st.php">
                <div class="card skill_sm">
                    <h2><span>S</span>ubconcious<span>M</span>ind</h2>
                </div>
            </a>
            <a href="prof_st.php">
                <div class="card skill_obj">
                    <h2><span>O</span>bjection <span>H</span>andling</h2>
                </div>
            </a>
            <a href="prof_abhi.php">
                <div class="card skill_can">
                    <h2><span>C</span>anva<span>D</span>esigning</h2>
                </div>
            </a>
            <a href="prof_hari.php">
                <div class="card skill_web">
                    <h2><span>W</span>eb<span>D</span>evelopment</h2>
                </div>
            </a>
        </div>
        <svg id="svg_s" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 230">
            <path fill="#ffd700" fill-opacity="1" d="M0,224L26.7,208C53.3,192,107,160,160,133.3C213.3,107,267,85,320,80C373.3,75,427,85,480,74.7C533.3,64,587,32,640,58.7C693.3,85,747,171,800,186.7C853.3,203,907,149,960,133.3C1013.3,117,1067,139,1120,149.3C1173.3,160,1227,160,1280,176C1333.3,192,1387,224,1413,240L1440,256L1440,320L1413.3,320C1386.7,320,1333,320,1280,320C1226.7,320,1173,320,1120,320C1066.7,320,1013,320,960,320C906.7,320,853,320,800,320C746.7,320,693,320,640,320C586.7,320,533,320,480,320C426.7,320,373,320,320,320C266.7,320,213,320,160,320C106.7,320,53,320,27,320L0,320Z">
            </path>
        </svg>
    </div>

    <div class="prof" id="prof">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 230">
            <path fill="#ffd700" fill-opacity="1" d="M0,128L24,112C48,96,96,64,144,48C192,32,240,32,288,53.3C336,75,384,117,432,149.3C480,181,528,203,576,186.7C624,171,672,117,720,112C768,107,816,149,864,160C912,171,960,149,1008,138.7C1056,128,1104,128,1152,144C1200,160,1248,192,1296,197.3C1344,203,1392,181,1416,170.7L1440,160L1440,0L1416,0C1392,0,1344,0,1296,0C1248,0,1200,0,1152,0C1104,0,1056,0,1008,0C960,0,912,0,864,0C816,0,768,0,720,0C672,0,624,0,576,0C528,0,480,0,432,0C384,0,336,0,288,0C240,0,192,0,144,0C96,0,48,0,24,0L0,0Z">
            </path>
        </svg>
        <div class="h_prof">
            <h3><span>P</span>rofessional</h3>
        </div>
        <div class="slider">
            <div class="wrapper">
                <div class="carousel owl-carousel ">
                    <a href="prof_st.php">
                        <div class="card card-2">
                            <img src="image/prof_01.png" alt="">
                        </div>
                    </a>
                    <a href="prof_hari.php">
                        <div class="card card-3">
                            <img src="image/prof_02.png" alt="">
                        </div>
                    </a>
                    <a href="prof_abhi.php">
                        <div class="card card-4">
                            <img src="image/prof_03.png" alt="">
                        </div>
                    </a>
                    <a href="prof_st.php">
                        <div class="card card-5">
                            <img src="image/prof_01.png" alt="">
                        </div>
                    </a>
                    <a href="prof_hari.php">
                        <div class="card card-5">
                            <img src="image/prof_02.png" alt="">
                        </div>
                    </a>
                </div>
            </div>
            <svg id="svg_p" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 300">
                <path fill="#ffd700" fill-opacity="1" d="M0,128L16,133.3C32,139,64,149,96,133.3C128,117,160,75,192,101.3C224,128,256,224,288,245.3C320,267,352,213,384,181.3C416,149,448,139,480,160C512,181,544,235,576,240C608,245,640,203,672,160C704,117,736,75,768,69.3C800,64,832,96,864,138.7C896,181,928,235,960,261.3C992,288,1024,288,1056,266.7C1088,245,1120,203,1152,181.3C1184,160,1216,160,1248,176C1280,192,1312,224,1344,202.7C1376,181,1408,107,1424,69.3L1440,32L1440,320L1424,320C1408,320,1376,320,1344,320C1312,320,1280,320,1248,320C1216,320,1184,320,1152,320C1120,320,1088,320,1056,320C1024,320,992,320,960,320C928,320,896,320,864,320C832,320,800,320,768,320C736,320,704,320,672,320C640,320,608,320,576,320C544,320,512,320,480,320C448,320,416,320,384,320C352,320,320,320,288,320C256,320,224,320,192,320C160,320,128,320,96,320C64,320,32,320,16,320L0,320Z">
                </path>
            </svg>
        </div>

        <div class="cont" id="cont">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 290">
                <path fill="#ffd700" fill-opacity="1" d="M0,128L16,133.3C32,139,64,149,96,133.3C128,117,160,75,192,101.3C224,128,256,224,288,245.3C320,267,352,213,384,181.3C416,149,448,139,480,160C512,181,544,235,576,240C608,245,640,203,672,160C704,117,736,75,768,69.3C800,64,832,96,864,138.7C896,181,928,235,960,261.3C992,288,1024,288,1056,266.7C1088,245,1120,203,1152,181.3C1184,160,1216,160,1248,176C1280,192,1312,224,1344,202.7C1376,181,1408,107,1424,69.3L1440,32L1440,0L1424,0C1408,0,1376,0,1344,0C1312,0,1280,0,1248,0C1216,0,1184,0,1152,0C1120,0,1088,0,1056,0C1024,0,992,0,960,0C928,0,896,0,864,0C832,0,800,0,768,0C736,0,704,0,672,0C640,0,608,0,576,0C544,0,512,0,480,0C448,0,416,0,384,0C352,0,320,0,288,0C256,0,224,0,192,0C160,0,128,0,96,0C64,0,32,0,16,0L0,0Z">
                </path>
            </svg>
            <div class="h_cont">
                <h3><span>C</span>ontact<span>U</span>s</h3>
            </div>
            <div class="c_form">
                <div class="c_form_f">
                    <h3><span>G</span>et in touch</h3>
                    <p>Hello ! dear friend, I hope you are visited our site completely. Here is a simple contact form.
                        If you have any queries or suggestions you can message us directly.
                        We are waiting for your suggestions or queries
                        Thank you !! Have a great day. </p>
                    <div class="social_m">
                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                        <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                        <a href=""><i class="fa-brands fa-youtube"></i></a>
                        <a href=""><i class="fa-brands fa-twitter"></i></a>
                        <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="c_form_s">
                <p>
                        <?php 
                        if(isset($_POST['c_submit'])){
                            if (!$mail->send()) {
                               echo $mag_n,$mag_e;
                            } else {
                                echo $mag_s;
                                header('location:../index.php#cont');
                            }
                        }
                        ?>
                    </p>
                    <form action="" method="POST">
                        <input type="text" name="name" placeholder="Enter your name" required>
                        <input type="number" name="number" placeholder="Enter your mobile number" required>
                        <input type="email" name="email" placeholder="Enter your email" required>
                        <textarea name="massage" cols="30" rows="10" placeholder="What's your massage ??" required></textarea>
                        <input id="submit" type="submit" name="c_submit">
                    </form>
                </div>
            </div>
            <svg id="svg_c" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 300">
                <path fill="#ffd700" fill-opacity="1" d="M0,128L16,133.3C32,139,64,149,96,133.3C128,117,160,75,192,101.3C224,128,256,224,288,245.3C320,267,352,213,384,181.3C416,149,448,139,480,160C512,181,544,235,576,240C608,245,640,203,672,160C704,117,736,75,768,69.3C800,64,832,96,864,138.7C896,181,928,235,960,261.3C992,288,1024,288,1056,266.7C1088,245,1120,203,1152,181.3C1184,160,1216,160,1248,176C1280,192,1312,224,1344,202.7C1376,181,1408,107,1424,69.3L1440,32L1440,320L1424,320C1408,320,1376,320,1344,320C1312,320,1280,320,1248,320C1216,320,1184,320,1152,320C1120,320,1088,320,1056,320C1024,320,992,320,960,320C928,320,896,320,864,320C832,320,800,320,768,320C736,320,704,320,672,320C640,320,608,320,576,320C544,320,512,320,480,320C448,320,416,320,384,320C352,320,320,320,288,320C256,320,224,320,192,320C160,320,128,320,96,320C64,320,32,320,16,320L0,320Z">
                </path>
            </svg>
        </div>

        <script src="js/script.js"></script>

</body>

</html>