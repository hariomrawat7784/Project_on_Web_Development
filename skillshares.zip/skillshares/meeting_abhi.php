
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_01.css">
    <link rel="stylesheet" href="css/meeting.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tapestry&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <script src="https://kit.fontawesome.com/6018fcc079.js" crossorigin="anonymous"></script>

    <title>Meeting : Abhishek Chauhan</title>

</head>

<body>
    <div class="lc">
        <a href="https://api.whatsapp.com/message/U3S4TRIYFME3D1?autoload=1&app_absent=0"><img src="image/lc_01.png"
                alt="live chat"></a>
    </div>
    <div class="nav">
        <div class="logo">
            <a href="https://skillshares.in/"><span>S </span>kill<span> S </span>hares</a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="https://skillshares.in/"><span>H</span>ome</a></li>
                <li><a href="https://skillshares.in/#about"><span>A</span>bout</a></li>
                <li><a href="https://skillshares.in/#skill"><span>S</span>kills</a></li>
                <li><a href="https://skillshares.in/#prof"><span>P</span>rofessionals</a></li>
                <li id="uniqe"><a href="https://skillshares.in/#cont"><span>C</span>ontact <span>U</span>s</a></li>
            </ul>
            <div class="social_m">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>
    <div class="meet_web">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffd700" fill-opacity="1" d="M0,224L30,218.7C60,213,120,203,180,176C240,149,300,107,360,112C420,117,480,171,540,165.3C600,160,660,96,720,101.3C780,107,840,181,900,208C960,235,1020,213,1080,213.3C1140,213,1200,235,1260,234.7C1320,235,1380,213,1410,202.7L1440,192L1440,0L1410,0C1380,0,1320,0,1260,0C1200,0,1140,0,1080,0C1020,0,960,0,900,0C840,0,780,0,720,0C660,0,600,0,540,0C480,0,420,0,360,0C300,0,240,0,180,0C120,0,60,0,30,0L0,0Z"></path>
          </svg>
        <div class="meet_item">
        <div class="meet_img">
            <div class="slider">
                <div class="wrapper">
                    <div class="carousel owl-carousel ">
                        <div class="card card-1">
                            <a href="image/Abhi_01.png"><img src="image/Abhi_01.png" alt=""></a>
                        </div>
                        <div class="card card-2">
                            <a href="image/Abhi_02.png"><img src="image/a_m_02.png" alt=""></a>
                        </div>
                        <div class="card card-3">
                            <a href="image/Abhi_01.png"><img src="image/a_m_03.png" alt=""></a>
                        </div>
                        <div class="card card-4">
                            <a href="image/Abhi_03.png"><img src="image/a_m_02.png" alt=""></a>
                        </div>
                        <div class="card card-5">
                            <a href="image/Abhi_03.png"><img src="image/a_m_01.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="meet_con">
            <h2>"<span id="m_h">C</span>anva Designing"</h2>
            <p style="color: #fff;">
               <?php 
               if(isset($_POST['submit'])){
                  if($num){
                      if($m_num){
                         echo $m_mass;
                 }else {
                     echo $sent;
                 }
                  }else {
                     ?>
                     <a href="https://www.skillshares.in/">
                     <?php
                       echo $sin;
                       ?>
                       <script>
                                window.onload = setTimeout(
                                    function() {
                                        location.replace('index.php');
                                    },
                                    3000);
                            </script>
                       <?php
                     }
               }
                     ?>
                </a>
            </p>
            <form action="php/razorpay-php/pay.php" method="POST">
                 <input type="email" name="email" placeholder="Enter your mail" required>
                 <input type="number" name="amount" value="0" placeholder="Fee 0/- only" readonly>
                 <input type="submit" value="Process to Pay" name="submit">
            </form>
        </div>
    </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffd700" fill-opacity="1" d="M0,224L30,218.7C60,213,120,203,180,176C240,149,300,107,360,112C420,117,480,171,540,165.3C600,160,660,96,720,101.3C780,107,840,181,900,208C960,235,1020,213,1080,213.3C1140,213,1200,235,1260,234.7C1320,235,1380,213,1410,202.7L1440,192L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path>
        </svg>
    </div>

    <script src="js/meeting.js"></script>
</body>

</html>