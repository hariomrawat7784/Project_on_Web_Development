<?php include 'php/forget_p.php' ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_01.css">
    <link rel="stylesheet" href="css/Respons.css">
    <link rel="stylesheet" href="css/log.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tapestry&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <script src="https://kit.fontawesome.com/6018fcc079.js" crossorigin="anonymous"></script>

    <title>Skillshares : "Recover account"</title>
    <link href="/image/icon.png" rel="icon">
    <link href="/image/icon.png" rel="apple-touch-icon">
</head>

<body>
    <div class="lc">
        <a href="https://api.whatsapp.com/message/U3S4TRIYFME3D1?autoload=1&app_absent=0"><img src="image/lc.png" alt="live chat"></a>
    </div>
    <div class="nav">
        <div class="logo">
            <a href="https://www.skillshares.in/"><span>S </span>kill<span> S </span>hares</a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="https://www.skillshares.in/"><span>H</span>ome</a></li>
                <li><a href="https://www.skillshares.in/#about"><span>A</span>bout</a></li>
                <li><a href="https://www.skillshares.in/#skill"><span>S</span>kills</a></li>
                <li><a href="https://www.skillshares.in/#prof"><span>P</span>rofessionals</a></li>
                <li><a href="https://www.skillshares.in/#cont">contact us</a></li>
            </ul>
            <div class="social_m">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>
    <div class="log_main">
        <div class="main_sub">
            <p>Set your New Password</p>
            <p>
                <?php
                if (isset($_POST['submit'])) {
                    if ($chack) {
                        if ($iquery) {
                            echo $p_update;
                ?>
                            <script>
                                window.onload = setTimeout(
                                    function() {
                                        location.replace('./login.php');
                                    },
                                    4000);
                            </script>
                <?php
                        } else {
                            echo $p_n_update;
                        }
                    } else {
                        echo  $pass_n;
                    }
                }
                ?>
            </p>
            <form action="" method="POST">
                <input type="password" name="pass" placeholder="Enter Password" required>
                <input type="password" name="cpass" placeholder="Confirm Password" required>
                <input type="submit" name="submit" value="Update Password">
                <p>Have a account ?? <a href="login.php">Click here!</a></p>
            </form>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>

</html>