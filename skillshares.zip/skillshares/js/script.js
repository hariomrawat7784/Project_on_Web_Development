var navbar = document.querySelector(".nav");
window.onscroll = function () {
  if (this.scrollY > 30) {
    navbar.classList.add("sticky");
  }
  else {
    navbar.classList.remove("sticky");
  }
};
// window.onload = setTimeout(
//   function () {
//   for(var i = 0; i <= 1000; i++){
//     var menu = document.querySelector(".menu");
//     var c_menu = menu.classList.contains("active");
//     console.log(c_menu);
//   }
//     },
// 10*1000 );

// window.onclick = function () {
//   var menu = document.querySelector(".menu");
//     var c_menu = menu.classList.contains("active");
//     console.log(c_menu);
//     if(c_menu){
//     console.log("screen");
//      $('.nav .menu').toggleClass("active");
//   }
// };

$('.uniqe').click(function () {
  $('.sing').toggleClass("up");
});

$('.uniqe').click(function () {
  console.log("hello !");
  $('.nav .menu').toggleClass("active");
  $('.menu-btn i').toggleClass("active");
});

$('.but').click(function () {
  $('.sing').toggleClass("up");
});

window.onload = setTimeout(
  function() {
    var menu = document.querySelector(".menu");
    var c_menu = menu.classList.contains("active");
    console.log(c_menu);
    if(c_menu){
    console.log("screen");
     $('.nav .menu').toggleClass("active");
     $('.menu-btn i').toggleClass("active"); 
  }
    $('.sing').toggleClass("up");
  },
1000 );

$(".carousel").owlCarousel({
  margin: 20,
  loop: true,
  autoplay: true,
  autoplayTimeout: 2000,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1,
      nav: false
    },
    600: {
      items: 2,
      nav: false
    },
    1000: {
      items: 3,
      nav: false
    }
  }
});

$('.menu-btn').click(function () {
  $('.nav .menu').toggleClass("active");
  $('.menu-btn i').toggleClass("active");
});

// while(0){
// var menu = document.querySelector(".menu");
// var c_menu = menu.classList.contains("active");
// console.log(c_menu);
// if(c_menu){
// console.log("screen");
// window.onclick = function () {
//   $('.nav .menu').toggleClass("active");
//   $('.menu-btn i').toggleClass("active");
// };
// }
// };

$('.menu').click(function () {
  console.log("hello !");
  $('.nav .menu').toggleClass("active");
  $('.menu-btn i').toggleClass("active");
});