
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_01.css">
    <link rel="stylesheet" href="css/Respons.css">
    <link rel="stylesheet" href="css/pro.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tapestry&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comforter+Brush&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <script src="https://kit.fontawesome.com/6018fcc079.js" crossorigin="anonymous"></script>

    <title>Satyam vishwakarma</title>

</head>

<body>
    <div class="lc">
        <a href="https://api.whatsapp.com/message/U3S4TRIYFME3D1?autoload=1&app_absent=0"><img src="image/lc_01.png" alt="live chat"></a>
    </div>
    <div class="nav">
        <div class="logo">
            <a href="https://www.skillshares.in/"><span>S </span>kill<span> S </span>hares</a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="https://www.skillshares.in/#"><span>H</span>ome</a></li>
                <li><a href="https://www.skillshares.in/#about"><span>A</span>bout</a></li>
                <li><a href="https://www.skillshares.in/#skill"><span>S</span>kills</a></li>
                <li><a href="https://www.skillshares.in/#prof"><span>P</span>rofessionals</a></li>
                <li><a href="https://www.skillshares.in/#cont">contact us</a></li>
                <li class="uniqe">Sing up</li>
                <li class="uniqe log"><a href="login.php"><i class="fa-regular fa-user"></a></i></li>
            </ul>
            <div class="social_m">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>

       <div class="rotate">

       </div>
       <div class="pro_web">
           <div class="pro_data">
                <div class="pro_text">
                     <h2>" <span>P</span>ersnal branding / communication expert "</h2>
                     <p>Satyam vishwakarma, ( Personality development, communication skills & subconscious mind trainer ). Skills are the most powerful weapon which can leads you towards success in your life.</p>
                     <a href="#meeting"><span>M</span>eetings</a>
                </div>
                <div class="pro_photo">
                    <div class="rota">

                    </div>
                    <img src="image/pro_s.png" alt="">
              </div>
           </div>
       </div>
       <div class="slider_box" id="meeting">
        <div class="s_heading">
            <h3><span>M</span> eeting</h3>
        </div>
        <div class="slider">
            <div class="wrapper">
                <div class="carousel owl-carousel ">
                    <div class="card card-1">
                        <a href="meeting_st.php"><img src="image/m_st_01.jpeg" alt=""></a>
                    </div>
                    <div class="card card-2">
                        <a href="meeting_st.php"><img src="image/m_st_02.jpeg" alt=""></a>
                    </div>
                    <div class="card card-3">
                        <a href="meeting_st.php"><img src="image/m_st_03.jpeg" alt=""></a>
                    </div>
                    <div class="card card-4">
                        <a href="meeting_st.php"><img src="image/m_st_01.jpeg" alt=""></a>
                    </div>
                    <div class="card card-5">
                        <a href="meeting_st.php"><img src="image/m_st_02.jpeg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <script src="js/script.js"></script>
    </body>
    </html>